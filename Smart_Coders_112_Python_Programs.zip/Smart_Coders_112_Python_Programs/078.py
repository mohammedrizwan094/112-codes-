"""Problem 078: Right-angled triangle (stars)"""

n = int(input("Enter number of rows: "))
for row in range(1, n + 1):
    print("*" * row)
