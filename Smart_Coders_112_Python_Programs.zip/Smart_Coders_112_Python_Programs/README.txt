Smart Coders - 112 Practice Problems
Python solutions numbered 001.py through 112.py.

Each file is a separate beginner-friendly program. Run a file with:
    python 001.py

Notes:
- Problems 021 (ticket pricing), 027 (electricity slab rates), and 042 (scholarship eligibility) do not specify exact rules/thresholds in the assignment, so clearly labeled example criteria are used.
- Problem 024 uses example practice credentials: admin / python123.
- Problem 107 prints the exact 4x4 spiral matrix shown in the assignment.
