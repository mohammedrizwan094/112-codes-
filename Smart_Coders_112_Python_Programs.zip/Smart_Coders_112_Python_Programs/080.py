"""Problem 080: Right-aligned triangle"""

n = int(input("Enter number of rows: "))
for row in range(1, n + 1):
    print(" " * (n - row) + "*" * row)
